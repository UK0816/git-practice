# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '0f44f38eb46d8caae8861dca8779febf6b99a68cff15193267a8b89ad07fbe9daf5abaf6daaa97fb62ddc2cd5355b80751a637f4c65fe79f79716ac43151b162'